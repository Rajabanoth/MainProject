package com.employee.model;

public class User {
	protected int id;
	protected String name;
	protected String email;
	protected String phno;

	public User() {
	}

	public User(String name, String email, String phno) {
		super();
		this.name = name;
		this.email = email;
		this.phno = phno;
	}

	public User(int id, String name, String email, String phno) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phno = phno;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getphno() {
		return phno;
	}
	public void setphno(String phno) {
		this.phno = phno;
	}
}